All your precious data is backed up here!.
The backup structure is as follows:
Folder 0 : 30 mins old backups
Folder 1 : 6 hr old backups
Folder 2 : 24 hr old backups